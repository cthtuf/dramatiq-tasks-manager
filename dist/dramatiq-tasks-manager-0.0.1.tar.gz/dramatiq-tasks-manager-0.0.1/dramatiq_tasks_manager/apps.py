from django.apps import AppConfig


class DramatiqtasksmanagerConfig(AppConfig):
    name = 'dramatiq_tasks_manager'
